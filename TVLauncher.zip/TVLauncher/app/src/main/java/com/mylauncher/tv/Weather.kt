package com.mylauncher.tv

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

/** Weather from Open-Meteo (free, no API key). Call off the main thread. */
object Weather {

    data class Result(val temp: Int, val code: Int, val city: String)

    fun fetch(city: String): Result? = try {
        val q = URLEncoder.encode(city, "UTF-8")
        val geo = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1"))
        val place = geo.optJSONArray("results")?.getJSONObject(0)
        if (place == null) null else {
            val lat = place.getDouble("latitude")
            val lon = place.getDouble("longitude")
            val w = JSONObject(
                get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code")
            ).getJSONObject("current")
            Result(w.getDouble("temperature_2m").roundToInt(), w.getInt("weather_code"), place.getString("name"))
        }
    } catch (e: Exception) {
        null
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    /** WMO weather code -> (emoji, description) */
    fun describe(code: Int): Pair<String, String> = when (code) {
        0 -> "☀️" to "Clear"
        1, 2 -> "⛅" to "Partly cloudy"
        3 -> "☁️" to "Cloudy"
        45, 48 -> "🌫️" to "Fog"
        in 51..57 -> "🌦️" to "Drizzle"
        in 61..67, in 80..82 -> "🌧️" to "Rain"
        in 71..77, 85, 86 -> "❄️" to "Snow"
        in 95..99 -> "⛈️" to "Thunderstorm"
        else -> "🌡️" to "—"
    }
}
