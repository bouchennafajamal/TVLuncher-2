package com.mylauncher.tv

import android.content.Intent
import android.graphics.drawable.Drawable

data class AppItem(
    val label: String,
    val pkg: String,
    val icon: Drawable,
    val banner: Drawable? = null,
    val intent: Intent? = null   // shortcuts (Settings, Network...)
)
