package com.mylauncher.tv

import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

private class Row(val title: String, val items: List<AppItem>, val orbs: Boolean = false, val inDock: Boolean = true)

class MainActivity : AppCompatActivity() {

    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private lateinit var root: FrameLayout
    private lateinit var dim: View
    private lateinit var rowsScroll: ScrollView
    private lateinit var rowsBox: LinearLayout
    private lateinit var dockArea: View
    private lateinit var dockRow: RecyclerView
    private lateinit var weatherTemp: TextView
    private lateinit var weatherInfo: TextView
    private lateinit var netIcon: ImageView
    private lateinit var vpnIcon: ImageView
    private lateinit var searchOrb: View
    private lateinit var searchPill: View
    private lateinit var tabs: View
    private lateinit var tabForYou: TextView
    private lateinit var tabApps: TextView
    private lateinit var heroText: TextView
    private var tab = 0

    private var allApps: List<AppItem> = emptyList()
    private var lastWeather = 0L

    private val statusTick = object : Runnable {
        override fun run() { updateStatus(); ui.postDelayed(this, 5000) }
    }

    // ---- settings (persisted) ----
    private val layoutMode get() = prefs.getInt("layout", 3)      // 0 carousel, 1 grid, 2 dock, 3 google tv
    private val labelMode get() = prefs.getInt("labels", 0)       // 0 focus, 1 always, 2 hidden
    private val showTitles get() = prefs.getBoolean("titles", true)
    private val scalePct get() = prefs.getInt("scale", 100)
    private val dimPct get() = prefs.getInt("dim", 0)
    private val sysWallpaper get() = prefs.getBoolean("syswp", false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        dim = findViewById(R.id.dim)
        rowsScroll = findViewById(R.id.rowsScroll)
        rowsBox = findViewById(R.id.rowsBox)
        dockArea = findViewById(R.id.dockArea)
        dockRow = findViewById(R.id.dockRow)
        weatherTemp = findViewById(R.id.weatherTemp)
        weatherInfo = findViewById(R.id.weatherInfo)
        netIcon = findViewById(R.id.netIcon)
        vpnIcon = findViewById(R.id.vpnIcon)
        searchOrb = findViewById(R.id.searchOrb)
        searchPill = findViewById(R.id.searchPill)
        tabs = findViewById(R.id.tabs)
        tabForYou = findViewById(R.id.tabForYou)
        tabApps = findViewById(R.id.tabApps)
        heroText = findViewById(R.id.heroText)
        tabForYou.setOnClickListener { setTab(0) }
        tabApps.setOnClickListener { setTab(1) }
        tabForYou.setOnFocusChangeListener { _, f -> if (f) setTab(0) }
        tabApps.setOnFocusChangeListener { _, f -> if (f) setTab(1) }
        searchPill.setOnClickListener { open(Intent(Intent.ACTION_ASSIST)) }

        dockRow.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)

        findViewById<View>(R.id.settingsOrb).setOnClickListener { showSettings() }
        findViewById<View>(R.id.searchOrb).setOnClickListener { open(Intent(Intent.ACTION_ASSIST)) }
        findViewById<View>(R.id.weatherBox).setOnClickListener { askCity() }
        netIcon.setOnClickListener { open(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        vpnIcon.setOnClickListener { open(Intent(Settings.ACTION_VPN_SETTINGS)) }
    }

    override fun onResume() {
        super.onResume()
        applyAppearance()
        loadApps()
        ui.post(statusTick)
        if (System.currentTimeMillis() - lastWeather > 30 * 60 * 1000) loadWeather()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(statusTick)
    }

    // A launcher is the root screen: Back does nothing.
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() { }

    // ---------------- appearance ----------------

    private fun applyAppearance() {
        dim.alpha = dimPct / 100f
        if (sysWallpaper) root.background = null else root.setBackgroundResource(R.drawable.bg_gradient)
        val dock = layoutMode == 2
        rowsScroll.visibility = if (dock) View.GONE else View.VISIBLE
        dockArea.visibility = if (dock) View.VISIBLE else View.GONE

        val gtv = layoutMode == 3
        searchOrb.visibility = if (gtv) View.GONE else View.VISIBLE
        searchPill.visibility = if (gtv) View.VISIBLE else View.GONE
        tabs.visibility = if (gtv) View.VISIBLE else View.GONE
        heroText.visibility = if (gtv && tab == 0) View.VISIBLE else View.GONE
        heroText.text = greeting()
        tabForYou.isSelected = tab == 0
        tabApps.isSelected = tab == 1
        tabForYou.setTextColor(if (tab == 0) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        tabApps.setTextColor(if (tab == 1) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
    }

    private fun setTab(i: Int) {
        if (i == tab) return
        tab = i
        applyAppearance()
        rebuild()
    }

    private fun greeting(): String {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when {
            h < 12 -> "Good morning"
            h < 18 -> "Good afternoon"
            else -> "Good evening"
        }
    }

    private fun applyAll() { applyAppearance(); rebuild() }

    // ---------------- status bar ----------------

    @Suppress("DEPRECATION")
    private fun updateStatus() {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        var wifi = false; var eth = false; var vpn = false
        try {
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) vpn = true
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifi = true
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) eth = true
            }
        } catch (e: Exception) { }
        netIcon.setImageResource(if (eth) R.drawable.ic_lan else R.drawable.ic_wifi)
        netIcon.alpha = if (wifi || eth) 1f else 0.3f
        vpnIcon.visibility = if (vpn) View.VISIBLE else View.GONE
    }

    // ---------------- apps ----------------

    private fun loadApps() {
        io.execute {
            val pm = packageManager
            val found = LinkedHashMap<String, AppItem>()
            for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
                val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
                for (ri in pm.queryIntentActivities(q, 0)) {
                    val pkg = ri.activityInfo.packageName
                    if (pkg == packageName || found.containsKey(pkg)) continue
                    found[pkg] = AppItem(
                        label = ri.loadLabel(pm).toString(),
                        pkg = pkg,
                        icon = ri.loadIcon(pm),
                        banner = ri.activityInfo.loadBanner(pm)
                    )
                }
            }
            val list = found.values.sortedBy { it.label.lowercase() }
            ui.post { allApps = list; rebuild() }
        }
    }

    private fun shortcut(label: String, iconRes: Int, intent: Intent) =
        AppItem(label, "shortcut:$label", AppCompatResources.getDrawable(this, iconRes)!!, intent = intent)

    private fun rebuild() {
        val hidden = list("hidden").toSet()
        val visible = allApps.filter { it.pkg !in hidden }
        val byPkg = visible.associateBy { it.pkg }
        val secs = sections()
        val sectioned = secs.values.flatten().toSet()

        val rows = mutableListOf<Row>()
        rows += Row(getString(R.string.recent), list("recent").mapNotNull { byPkg[it] }, inDock = false)
        rows += Row(getString(R.string.favorites), list("favs").mapNotNull { byPkg[it] })
        secs.forEach { (name, pkgs) -> rows += Row(name, pkgs.mapNotNull { byPkg[it] }) }
        rows += Row(getString(R.string.apps), visible.filter { it.pkg !in sectioned })
        rows += Row(
            getString(R.string.settings),
            listOf(
                shortcut(getString(R.string.settings), R.drawable.ic_settings, Intent(Settings.ACTION_SETTINGS)),
                shortcut(getString(R.string.network), R.drawable.ic_wifi, Intent(Settings.ACTION_WIFI_SETTINGS))
            ),
            orbs = true
        )
        val shown = rows.filter { it.items.isNotEmpty() }
        val scale = scalePct / 100f

        if (layoutMode == 2) {
            val flat = shown.filter { it.inDock }.flatMap { it.items }.distinctBy { it.pkg }
            dockRow.adapter = AppAdapter(R.layout.item_dock, 14, scale, labelMode, false, ::launch, ::showOptions)
                .also { it.submit(flat) }
            return
        }

        val gtv = layoutMode == 3
        val toShow: List<Row> = if (gtv) {
            if (tab == 0) {
                val yours = (rows[0].items + visible).distinctBy { it.pkg }
                listOf(Row("Your apps", yours)) +
                    shown.filter { r -> !r.orbs && r !== rows[0] && r.title != getString(R.string.apps) }
            } else listOf(Row("All apps", visible))
        } else shown
        val cardW = if (gtv) 188 else 220
        val d = resources.displayMetrics
        val span = (((d.widthPixels / d.density) - 96) / (cardW * scale)).toInt().coerceAtLeast(2)
        val grid = layoutMode == 1 || (gtv && tab == 1)

        rowsBox.removeAllViews()
        for (r in toShow) {
            if (showTitles) rowsBox.addView(TextView(this).apply {
                text = r.title
                setTextColor(0xE6FFFFFF.toInt())
                textSize = 18f
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).also { it.setMargins(dp(10), dp(20), 0, 0) }
            })
            val adapter = AppAdapter(
                if (r.orbs) R.layout.item_orb else if (gtv) R.layout.item_gtv else R.layout.item_app,
                if (r.orbs) 20 else if (gtv) 22 else 32, scale, labelMode, true, ::launch,
                if (r.orbs) null else ::showOptions
            ).also { it.submit(r.items) }
            rowsBox.addView(RecyclerView(this).apply {
                clipChildren = false
                clipToPadding = false
                isNestedScrollingEnabled = false
                layoutManager =
                    if (grid && !r.orbs) GridLayoutManager(this@MainActivity, span)
                    else LinearLayoutManager(this@MainActivity, RecyclerView.HORIZONTAL, false)
                this.adapter = adapter
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            })
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun open(i: Intent) {
        try { startActivity(i) }
        catch (e: Exception) { Toast.makeText(this, "Not available on this device", Toast.LENGTH_SHORT).show() }
    }

    private fun launch(item: AppItem) {
        item.intent?.let { open(it); return }
        pushRecent(item.pkg)
        val i = packageManager.getLeanbackLaunchIntentForPackage(item.pkg)
            ?: packageManager.getLaunchIntentForPackage(item.pkg)
        if (i != null) open(i)
        else Toast.makeText(this, "Cannot open ${item.label}", Toast.LENGTH_SHORT).show()
    }

    // ---------------- app menu ----------------

    private fun showOptions(item: AppItem) {
        val isFav = list("favs").contains(item.pkg)
        val options = arrayOf(
            getString(if (isFav) R.string.remove_fav else R.string.add_fav),
            "Move to section…",
            "Hide app",
            getString(R.string.app_info),
            getString(R.string.uninstall)
        )
        AlertDialog.Builder(this)
            .setTitle(item.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> { toggle("favs", item.pkg); rebuild() }
                    1 -> moveToSection(item)
                    2 -> { toggle("hidden", item.pkg); rebuild() }
                    3 -> open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${item.pkg}")))
                    4 -> open(Intent(Intent.ACTION_DELETE, Uri.parse("package:${item.pkg}")))
                }
            }
            .show()
    }

    private fun moveToSection(item: AppItem) {
        val secs = sections()
        val names = secs.keys.toMutableList()
        val current = names.firstOrNull { secs[it]!!.contains(item.pkg) }
        val options = names.toMutableList().apply {
            add("New section…")
            if (current != null) add("Remove from \"$current\"")
        }
        AlertDialog.Builder(this)
            .setTitle("Section")
            .setItems(options.toTypedArray()) { _, which ->
                secs.values.forEach { it.remove(item.pkg) }
                when {
                    which < names.size -> { secs[names[which]]!!.add(item.pkg); saveSections(secs); rebuild() }
                    which == names.size -> askText("New section", "") { n ->
                        val s2 = sections()
                        s2.values.forEach { it.remove(item.pkg) }
                        s2.getOrPut(n) { mutableListOf() }.add(item.pkg)
                        saveSections(s2); rebuild()
                    }
                    else -> { saveSections(secs); rebuild() }
                }
            }
            .show()
    }

    // ---------------- settings dialog ----------------

    private fun showSettings() {
        val layouts = arrayOf("Carousel", "Grid", "Dock", "Google TV")
        val labels = arrayOf("On focus", "Always", "Hidden")
        val items = arrayOf(
            "Layout: ${layouts[layoutMode]}",
            "App labels: ${labels[labelMode]}",
            "Section titles: ${if (showTitles) "On" else "Off"}",
            "UI size: $scalePct%",
            "Wallpaper dim: $dimPct%",
            "System wallpaper: ${if (sysWallpaper) "On" else "Off"}",
            "Hidden apps…",
            "Delete a section…",
            "Weather city: ${city()}"
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.settings)
            .setItems(items) { _, w ->
                when (w) {
                    0 -> choose("Layout", layouts, layoutMode) { prefs.edit().putInt("layout", it).apply() }
                    1 -> choose("App labels", labels, labelMode) { prefs.edit().putInt("labels", it).apply() }
                    2 -> { prefs.edit().putBoolean("titles", !showTitles).apply(); applyAll(); showSettings() }
                    3 -> {
                        val v = intArrayOf(80, 90, 100, 110, 120, 130)
                        choose("UI size", v.map { "$it%" }.toTypedArray(), v.indexOf(scalePct)) {
                            prefs.edit().putInt("scale", v[it]).apply()
                        }
                    }
                    4 -> {
                        val v = intArrayOf(0, 20, 40, 60, 80)
                        choose("Wallpaper dim", v.map { "$it%" }.toTypedArray(), v.indexOf(dimPct)) {
                            prefs.edit().putInt("dim", v[it]).apply()
                        }
                    }
                    5 -> { prefs.edit().putBoolean("syswp", !sysWallpaper).apply(); applyAll(); showSettings() }
                    6 -> manageHidden()
                    7 -> deleteSection()
                    8 -> askCity()
                }
            }
            .show()
    }

    private fun choose(title: String, names: Array<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(names, current) { d, i -> onPick(i); d.dismiss(); applyAll(); showSettings() }
            .show()
    }

    private fun manageHidden() {
        val hidden = list("hidden").toMutableSet()
        if (allApps.isEmpty()) return
        val names = allApps.map { it.label }.toTypedArray()
        val checked = BooleanArray(allApps.size) { allApps[it].pkg in hidden }
        AlertDialog.Builder(this)
            .setTitle("Hidden apps (checked = hidden)")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton(R.string.ok) { _, _ ->
                val keep = allApps.filterIndexed { i, _ -> checked[i] }.map { it.pkg }
                putList("hidden", keep)
                rebuild()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun deleteSection() {
        val secs = sections()
        if (secs.isEmpty()) { Toast.makeText(this, "No custom sections", Toast.LENGTH_SHORT).show(); return }
        val names = secs.keys.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Delete section")
            .setItems(names) { _, i -> secs.remove(names[i]); saveSections(secs); rebuild() }
            .show()
    }

    private fun askText(title: String, initial: String, onOk: (String) -> Unit) {
        val input = EditText(this).apply {
            setText(initial)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton(R.string.ok) { _, _ ->
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) onOk(t)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------------- weather ----------------

    private fun city(): String = prefs.getString("city", "Casablanca")!!

    private fun loadWeather() {
        lastWeather = System.currentTimeMillis()
        io.execute {
            val r = Weather.fetch(city())
            ui.post {
                if (r == null) {
                    weatherTemp.text = "--°"
                    weatherInfo.text = city()
                    lastWeather = 0L
                } else {
                    val (emoji, text) = Weather.describe(r.code)
                    weatherTemp.text = "$emoji ${r.temp}°C"
                    weatherInfo.text = "$text · ${r.city}"
                }
            }
        }
    }

    private fun askCity() = askText(getString(R.string.change_city), city()) {
        prefs.edit().putString("city", it).apply()
        loadWeather()
    }

    // ---------------- storage helpers ----------------

    private fun list(key: String): List<String> =
        prefs.getString(key, "")!!.split(",").filter { it.isNotBlank() }

    private fun putList(key: String, l: List<String>) =
        prefs.edit().putString(key, l.joinToString(",")).apply()

    private fun toggle(key: String, pkg: String) {
        val l = list(key).toMutableList()
        if (!l.remove(pkg)) l.add(pkg)
        putList(key, l)
    }

    private fun pushRecent(pkg: String) {
        val l = list("recent").toMutableList()
        l.remove(pkg); l.add(0, pkg)
        putList("recent", l.take(10))
    }

    private fun sections(): LinkedHashMap<String, MutableList<String>> {
        val out = LinkedHashMap<String, MutableList<String>>()
        try {
            val o = JSONObject(prefs.getString("sections", "{}")!!)
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                out[k] = MutableList(a.length()) { a.getString(it) }
            }
        } catch (e: Exception) { }
        return out
    }

    private fun saveSections(m: Map<String, List<String>>) {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, JSONArray(v)) }
        prefs.edit().putString("sections", o.toString()).apply()
    }
}
