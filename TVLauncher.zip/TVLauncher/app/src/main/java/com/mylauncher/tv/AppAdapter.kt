package com.mylauncher.tv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * labelMode: 0 = show on focus, 1 = always, 2 = hidden
 * scale: UI size multiplier (1.0 = default)
 */
class AppAdapter(
    private val layoutRes: Int,
    private val iconPadDp: Int,
    private val scale: Float,
    private val labelMode: Int,
    private val preferBanner: Boolean,
    private val onClick: (AppItem) -> Unit,
    private val onLongClick: ((AppItem) -> Unit)? = null
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppItem> = emptyList()

    fun submit(list: List<AppItem>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: FrameLayout = v.findViewById(R.id.card)
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(layoutRes, parent, false)
        val h = VH(v)
        h.card.clipToOutline = true
        if (scale != 1f) {
            val lp = v.layoutParams
            if (lp.width > 0) lp.width = (lp.width * scale).toInt()
            val cl = h.card.layoutParams
            if (cl.width > 0) cl.width = (cl.width * scale).toInt()
            if (cl.height > 0) cl.height = (cl.height * scale).toInt()
        }
        return h
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]
        val d = h.itemView.resources.displayMetrics.density
        val banner = if (preferBanner) item.banner else null

        h.icon.setImageDrawable(banner ?: item.icon)
        if (banner != null) {
            h.icon.setPadding(0, 0, 0, 0)
            h.icon.scaleType = ImageView.ScaleType.CENTER_CROP
        } else {
            val p = (iconPadDp * d).toInt()
            h.icon.setPadding(p, p, p, p)
            h.icon.scaleType = ImageView.ScaleType.FIT_CENTER
        }

        h.label.text = item.label
        h.label.visibility = if (labelMode == 2) View.GONE else View.VISIBLE
        h.label.alpha = if (labelMode == 1) 1f else 0f

        h.card.setOnClickListener { onClick(item) }
        h.card.setOnLongClickListener(
            onLongClick?.let { cb -> View.OnLongClickListener { cb(item); true } }
        )
        h.card.setOnFocusChangeListener { _, focused ->
            val s = if (focused) 1.12f else 1f
            h.itemView.animate().scaleX(s).scaleY(s).setDuration(130).start()
            h.itemView.elevation = if (focused) 20f else 0f
            if (labelMode == 0) h.label.animate().alpha(if (focused) 1f else 0f).setDuration(130).start()
        }
    }

    override fun getItemCount() = items.size
}
